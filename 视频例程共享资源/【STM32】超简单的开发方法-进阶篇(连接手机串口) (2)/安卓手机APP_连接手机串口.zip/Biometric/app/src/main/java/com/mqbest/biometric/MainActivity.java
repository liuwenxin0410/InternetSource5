package com.mqbest.biometric;

import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.biometrics.BiometricPrompt;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private final String TAG = getClass().getSimpleName();


    private Button butFingerprint = null;
    private TextView tvStatus = null;
    private TextView tvSerialMsg = null;

    private Handler mainLooper = null;

    private enum UsbPermission { Unknown, Requested, Granted, Denied }
    public static final String INTENT_ACTION_GRANT_USB = BuildConfig.APPLICATION_ID + ".GRANT_USB";
    private SerialInputOutputManager usbIoManager = null;
    private UsbSerialPort usbSerialPort = null;
    private UsbPermission usbPermission = UsbPermission.Unknown;
    private boolean connected = false;

    private SerialInputOutputManager.Listener usbListener = new SerialInputOutputManager.Listener() {
        @Override
        public void onNewData(byte[] data) {
            mainLooper.post(() -> {
                recvSerial(data);
            });
        }

        @Override
        public void onRunError(Exception e) {

        }
    };

    private BroadcastReceiver mUsbStateChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            Log.d(TAG, "BroadcastReceiver: " + action);
            if(action.equals(UsbManager.ACTION_USB_DEVICE_ATTACHED)){
                openSerial();
            }else if(action.equals(UsbManager.ACTION_USB_DEVICE_DETACHED)){
                releaseSerial();
            }else if(action.equals(INTENT_ACTION_GRANT_USB)){
                openSerial();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releaseSerial();
        unregisterReceiver(mUsbStateChangeReceiver);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mainLooper.post(this::openSerial);
    }

    @Override
    public void onClick(View view) {
        Log.i(TAG, "btn id:"+view.getId());
        switch (view.getId()){
            case R.id.btn_fingerprint:

                startBiometricPrompt();

                break;
        }
    }

    private void initView(){
        butFingerprint = findViewById(R.id.btn_fingerprint);
        butFingerprint.setOnClickListener(this);
        tvStatus = (TextView) findViewById(R.id.tv_status);
        tvSerialMsg = (TextView)findViewById(R.id.et_msg);

        mainLooper = new Handler(Looper.getMainLooper());

        detectUsbWithBroadcast();
    }

    private void startBiometricPrompt(){
        BiometricPrompt mBiometricPrompt;
        CancellationSignal mCancellationSignal;
        BiometricPrompt.AuthenticationCallback mAuthenticationCallback;
        mBiometricPrompt = new BiometricPrompt.Builder(this)
                .setTitle("指纹识别")
                .setDescription("描述")
                .setNegativeButton("取消", getMainExecutor(), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.w(TAG, "取消指纹识别1");
//                        mCancellationSignal.cancel();
                    }
                })
                .build();
        mCancellationSignal = new CancellationSignal();
        mCancellationSignal.setOnCancelListener(new CancellationSignal.OnCancelListener() {
            @Override
            public void onCancel() {
                Log.w(TAG, "取消指纹识别2");
            }
        });

        mAuthenticationCallback = new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                Log.i(TAG, "onAuthenticationError:"+errorCode+":"+errString);
            }

            @Override
            public void onAuthenticationHelp(int helpCode, CharSequence helpString) {
                super.onAuthenticationHelp(helpCode, helpString);
            }

            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Log.i(TAG,"指纹匹配！"+result.toString());
                writeSerial("AuthenticationSucceeded");
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                writeSerial("onAuthenticationFailed");
                Log.e(TAG, "指纹不匹配");
            }
        };

        mBiometricPrompt.authenticate(mCancellationSignal, getMainExecutor(), mAuthenticationCallback);
    }


    private void openSerial(){
        // Find all available drivers from attached devices.
        UsbManager usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        List<UsbSerialDriver> availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
        if (availableDrivers.isEmpty()) {
            return ;
        }

        // Open a connection to the first available driver.
        UsbSerialDriver driver = availableDrivers.get(0);
        UsbDeviceConnection usbConnection = usbManager.openDevice(driver.getDevice());
        if(usbConnection == null && usbPermission == UsbPermission.Unknown && !usbManager.hasPermission(driver.getDevice())) {
            usbPermission = UsbPermission.Requested;
            PendingIntent usbPermissionIntent = PendingIntent.getBroadcast(getApplicationContext(), 0, new Intent(INTENT_ACTION_GRANT_USB), 0);
            usbManager.requestPermission(driver.getDevice(), usbPermissionIntent);
            return ;
        }
        if(usbConnection == null) {
            if (!usbManager.hasPermission(driver.getDevice())) {
                //status("connection failed: permission denied");
            }else {
                status("connection failed: open failed");
            }
            return ;
        }
        usbSerialPort = driver.getPorts().get(0); // Most devices have just one port (port 0)
        try {
            usbSerialPort.open(usbConnection);
            usbSerialPort.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            usbIoManager = new SerialInputOutputManager(usbSerialPort, usbListener);
            usbIoManager.start();
            connected = true;
        } catch (IOException e) {
            e.printStackTrace();
            connected = false;
            usbSerialPort = null;
            return ;
        }
    }

    private void writeSerial(String msg){
        if(!connected) {
            status("串口未连接！");return;
        }
        byte[] data = (msg + '\n').getBytes();
        try {
            usbSerialPort.write(data, 2000);

            SpannableStringBuilder spn = new SpannableStringBuilder();
            spn.append("发送:"+msg+"\n");
            //spn.setSpan(new BackgroundColorSpan(ContextCompat.getColor(this,R.color.black)),0,spn.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            tvSerialMsg.append(spn);
        } catch (IOException e) {
            e.printStackTrace();
            status("串口发送出错！");
        }
    }

    private void recvSerial(byte[] data){
        try {
            String msg = new String(data, "UTF-8");
            SpannableStringBuilder spn = new SpannableStringBuilder();
            spn.append("接收:"+msg+"\n");
            //spn.setSpan(new BackgroundColorSpan(ContextCompat.getColor(this,R.color.bule)),0,spn.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            tvSerialMsg.append(spn);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    private void releaseSerial(){
        connected = false;
        if(usbIoManager != null) {
            usbIoManager.setListener(null);
            usbIoManager.stop();
        }
        usbIoManager = null;
        if(null != usbSerialPort) {
            try {
                usbSerialPort.close();
            } catch (IOException ignored) {
            }
        }
        usbSerialPort = null;
        usbPermission = UsbPermission.Unknown;
    }

    private void detectUsbWithBroadcast() {
        Log.d(TAG, "listenUsb: register");
        IntentFilter filter = new IntentFilter();
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        filter.addAction(INTENT_ACTION_GRANT_USB);
        registerReceiver(mUsbStateChangeReceiver, filter);
        Log.d(TAG, "listenUsb: registered");
    }

    private void status(String status){
//        SpannableStringBuilder spn = new SpannableStringBuilder();
//        spn.append(status);
//        spn.setSpan(new BackgroundColorSpan(ContextCompat.getColor(this,R.color.bule)),0,spn.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvStatus.setText(status);
        //tvStatus.append(spn);
    }
}